# Markov Chain Approach for UE-Side Cellular Anomaly Detection

This document extracts the probabilistic Markov chain component of UE-Guard. The deterministic specification layer is intentionally excluded. The content here covers state representation, training, scoring, threshold calibration, evaluation results, and conclusions specific to the Markov chain detector.

## 1. Motivation

Legitimate cellular signaling follows highly predictable patterns dictated by the 3GPP protocol specification. A first-order Markov chain captures this structure with a small parameter footprint and without the runtime cost of a neural network. The model assigns a probability to every observed state-to-state transition during training and uses that distribution at detection time to flag rare or unseen behavior.

Two design constraints shape the approach. The first is that the same model must operate across LTE, 5G-SA, and 5G-NSA without separate retraining. The second is that scoring must remain interpretable, so anomaly values can be traced back to a specific transition probability and a specific message field.

## 2. State Representation

Each protocol message in a captured trace is mapped to a state identifier composed of a four-tuple.

```
state_id = (packet_type, direction, message_type, network_type)
```

Examples.

```
(nas-eps, UL, Attach Request, LTE)
(nr-rrc, DL, RRC Setup, 5G)
(rrc, UL, RRC Connection Setup Complete, COMMON)
```

The `network_type` slot is auto-detected from packet fields and tagged as `LTE`, `5G`, or `COMMON`. Cross-network transitions, such as those that occur during NSA mode handover, are tracked as ordinary transitions in the same model. Universal broadcast messages, namely System Information Blocks and Paging, are treated separately because they may originate from any preceding state.

## 3. Training Phase

### 3.1 Inputs and outputs

Training consumes a set of normal traces $\mathcal{N} = \{T_1, T_2, \ldots, T_k\}$ and produces three artifacts.

- $\mathcal{T}$, the learned transition probability table indexed by `(src, dst)`.
- $\mathcal{F}$, the learned per-field value distributions.
- $S_{\max}$, the maximum surprise observed in the training data, used as a normalization constant.

### 3.2 Counting phase

For each trace, the learner walks rows in order, maintains the previous state, and increments two structures. The transition counter $C_{ij}$ counts how often state $i$ is followed by state $j$. The field counter $F_f[v]$ counts how often field $f$ takes value $v$ across all rows. Constraint fields tracked include the cause code, identity type, and security algorithm identifiers.

### 3.3 Probability estimation with Laplace smoothing

After counting, the learner computes the conditional transition probability with additive smoothing.

$$
P(j \mid i) = \frac{C_{ij} + \alpha}{\sum_{j'} C_{ij'} + \alpha \cdot |\mathcal{S}|}, \quad \alpha = 10^{-4}
$$

The smoothing constant $\alpha$ is small. Its purpose is not to bias the model but to keep the surprise computation defined when a transition has zero observed count, so unseen edges do not produce $-\log_2(0)$.

### 3.4 Maximum surprise normalization

The training pipeline computes the largest surprise value present in the learned distribution.

$$
S_{\max} = \max_{(i,j) \in \mathcal{T}} \left( -\log_2 P(j \mid i) \right)
$$

$S_{\max}$ is used at detection time so that all per-row scores are normalized into $[0, 1]$ regardless of the operator's traffic mix.

### 3.5 Training pseudocode

```
Procedure TrainMarkovChain
    Require Normal traces N
    Ensure Transitions T, field distributions F, max surprise Smax

    C ← empty map of (state, state) → integer
    F_f ← empty map of value → integer for each field f
    S ← empty set of states

    for each trace t in N do
        s_prev ← null
        for each row r in t do
            s_curr ← StateID(r)
            S ← S ∪ {s_curr}
            if s_prev ≠ null then
                C[s_prev, s_curr] ← C[s_prev, s_curr] + 1
            end if
            for each field f in {cause, identity_type, algo} do
                F_f[r.f] ← F_f[r.f] + 1
            end for
            s_prev ← s_curr
        end for
    end for

    α ← 1e-4
    for each source state i in S do
        total_i ← Σ_j C[i, j] + α · |S|
        for each destination state j in S do
            T[i, j] ← (C[i, j] + α) / total_i
        end for
    end for

    Smax ← max over (i, j) in T of (−log2 T[i, j])
    return ⟨T, F, Smax⟩
```

## 4. Detection Phase

Detection produces a continuous anomaly score in $[0, 1]$ for every row, then aggregates the row scores into a trace-level decision value.

### 4.1 Transition score

For an incoming row with previous state $s_{\text{prev}}$ and current state $s_{\text{curr}}$, the transition score is computed by case.

$$
\text{score}_{\text{trans}}(s_{\text{prev}} \to s_{\text{curr}}) =
\begin{cases}
\dfrac{-\log_2 P(s_{\text{curr}} \mid s_{\text{prev}})}{S_{\max}} & \text{if } (s_{\text{prev}}, s_{\text{curr}}) \in \mathcal{T} \\
0.9 & \text{if } s_{\text{curr}} \in \mathcal{S}, (s_{\text{prev}}, s_{\text{curr}}) \notin \mathcal{T} \\
1.0 & \text{if } s_{\text{curr}} \notin \mathcal{S}
\end{cases}
$$

Common transitions yield low scores. As a rough guide, a transition with $P = 0.9$ produces a score near 0.15. A transition with $P = 0.01$ produces a score near 0.66. An edge that was never observed during training but lands on a known state is fixed at 0.9. A message that lands on a state never seen during training is fixed at 1.0.

### 4.2 Field rarity score

Each row also carries a field rarity score. For each tracked field $f$ with value $v$, the score is computed from the empirical field distribution.

$$
\text{score}_f =
\begin{cases}
\min\left(\dfrac{-\log_2 P(v)}{S_{\max}}, 1.0\right) & \text{if } v \in \mathcal{F}[f] \\
1.0 & \text{otherwise}
\end{cases}
$$

The field component of the row is the mean of the per-field scores. If no constraint fields are present, the field component is zero.

### 4.3 Per-row score combination

The final per-row score is a weighted sum of the transition and field components.

$$
\text{score}_{\text{row}} = w_t \cdot \text{score}_{\text{trans}} + w_f \cdot \text{score}_{\text{field}}, \quad w_t = 0.7, \, w_f = 0.3
$$

The weighting reflects domain knowledge that message sequencing is a stronger signal than individual field values.

### 4.4 Trace-level aggregation

A trace receives a single score that combines three statistics over its rows.

$$
\text{score}_{\text{trace}} = w_{\text{mean}} \cdot \text{mean}(\text{scores}) + w_{\text{max}} \cdot \max(\text{scores}) + w_{\text{flag}} \cdot \frac{|\{r : \text{score}_r \geq \theta_{\text{row}}\}|}{|T|}
$$

The defaults are $w_{\text{mean}} = 0.4$, $w_{\text{max}} = 0.3$, $w_{\text{flag}} = 0.3$, and $\theta_{\text{row}} = 0.5$. The flag fraction term gives weight to traces with multiple highly anomalous messages even if the mean is dragged down by long benign segments.

### 4.5 Detection pseudocode

```
Procedure ScoreTrace
    Require Trace T, learned model ⟨T, F, Smax⟩
    Require Weights wt = 0.7, wf = 0.3, θ_row = 0.5
    Ensure Trace-level anomaly score score_trace

    scores ← []
    flagged ← 0
    s_prev ← null

    for each row r in T do
        s_curr ← StateID(r)

        if s_prev = null then
            score_trans ← 0.0
        else if (s_prev, s_curr) in T then
            P ← T[s_prev, s_curr]
            score_trans ← min(−log2(P) / Smax, 1.0)
        else if s_curr in S then
            score_trans ← 0.9
        else
            score_trans ← 1.0
        end if

        field_scores ← []
        for each field f in r with value v do
            if f in F ∧ v in F[f] then
                Pf ← F[f, v]
                score_f ← min(−log2(Pf) / Smax, 1.0)
            else
                score_f ← 1.0
            end if
            field_scores.append(score_f)
        end for
        score_field ← mean(field_scores) if field_scores ≠ [] else 0.0

        score_row ← wt · score_trans + wf · score_field
        scores.append(score_row)
        if score_row ≥ θ_row then
            flagged ← flagged + 1
        end if
        s_prev ← s_curr
    end for

    score_trace ← 0.4 · mean(scores) + 0.3 · max(scores) + 0.3 · (flagged / |T|)
    return score_trace
```

## 5. Adaptive Threshold Calibration

The trace-level score is converted into a binary decision by comparing against a single learned threshold $\theta_{\text{anomaly}}$. The calibration procedure performs a grid search over candidate thresholds and selects the value that maximizes classification accuracy on labeled data.

$$
\theta_{\text{anomaly}}^{*} = \arg\max_{\theta} \frac{TP(\theta) + TN(\theta)}{TP(\theta) + TN(\theta) + FP(\theta) + FN(\theta)}
$$

The candidate set is the union of every observed trace score and every adjacent midpoint, ensuring that any score-induced split point is reachable. Other coefficients of the scoring function are kept static so only one parameter is adapted from data. This minimizes the surface that the calibrator can overfit and keeps the model interpretable across redeployments.

The optimal value learned on the evaluation dataset is $\theta_{\text{anomaly}}^{*} = 0.2858$.

## 6. Trained Model Statistics

The Markov chain learned from seven normal samples produces the following structure.

| Property | Value |
|---|---|
| Distinct states $\|\mathcal{S}\|$ | 26 |
| Learned transitions $\|\mathcal{T}\|$ | 55 |
| Probability range | $[0.014, 1.0]$ |
| Smoothing constant $\alpha$ | $10^{-4}$ |
| Max surprise $S_{\max}$ | computed from data |

Network type tagging means that a single trained model handles LTE traces, 5G-SA traces, and traces that mix the two during NSA operation. No separate per-network retraining is required.

## 7. Evaluation Results

### 7.1 Dataset

The evaluation set contains 51 samples covering 17,096 protocol messages. Seven of the traces are normal captures from operator networks. The remaining 44 are attack traces produced in a controlled lab using Open5GS and srsRAN, supplemented with public samples from the FBSDetector repository.

| Category | Samples |
|---|---|
| State manipulation | 13 |
| Encryption and security bypass | 9 |
| Service rejection | 7 |
| Network downgrade | 4 |
| Location tracking | 3 |
| Identity catching | 3 |
| Resource depletion | 3 |
| Protocol failures | 2 |
| Normal | 7 |

### 7.2 Score separation

The Markov chain scoring produces a clean numerical gap between normal and attack traces. The normal cluster spans $[0.098, 0.247]$. The attack cluster spans $[0.325, 0.653]$. There is no overlap, which is why a single learned threshold at 0.2858 partitions the dataset without error.

### 7.3 Detection accuracy

The Markov chain layer paired with adaptive thresholding achieves perfect classification on the dataset.

| System | Accuracy | TP | TN | FP | FN | TPR | TNR |
|---|---|---|---|---|---|---|---|
| Markov chain layer with adaptive threshold | 100% | 44 | 7 | 0 | 0 | 100% | 100% |
| LSTM baseline | 92.16% | 41 | 6 | 1 | 3 | 93.2% | 85.7% |
| GRU baseline | 88.24% | 40 | 5 | 2 | 4 | 90.9% | 71.4% |
| CNN baseline | 82.35% | 38 | 4 | 3 | 6 | 86.4% | 57.1% |

### 7.4 Computational efficiency

The Markov chain layer is small and fast on commodity hardware.

| Metric | Markov layer | LSTM baseline | Improvement |
|---|---|---|---|
| Detection latency per trace | 11.68 ms | 875 ms | 74.9x faster |
| Memory footprint | 0.19 MB | 86.75 MB | 456x smaller |
| Time complexity | $O(n)$ | $O(n h^2)$ | linear vs quadratic in hidden width |

The cost per message is dominated by two hash table lookups, one for the transition probability and one for the field rarity. No vector arithmetic is needed at detection time.

## 8. Why the Markov Chain Approach Works

Three properties explain the empirical accuracy.

The first is that 3GPP protocol traces are highly structured. The set of valid next-message types from any given state is small, so the empirical distribution is sharply peaked. Rare and unseen transitions are therefore meaningful signals rather than noise.

The second is that the four-tuple state representation isolates network type as part of the state, which removes the need to merge LTE and 5G probability mass under a single label. Without this separation, frequent LTE transitions would absorb the probability budget that legitimate but rare 5G transitions require.

The third is that information-theoretic surprise gives a natural ordering between common, rare, unseen, and unknown events. Common events produce a low score, rare events produce a moderate score, unseen edges produce 0.9, and unknown destination states produce the maximum 1.0. This monotone scale matches the intuitive notion of anomalousness and avoids the calibration problems of unbounded log-likelihood scores.

## 9. Limitations

The approach has clear boundaries.

It cannot detect attacks whose individual messages are protocol-valid and whose transitions appear in normal traffic. Such attacks must be caught by higher-level reasoning over content fields or by the deterministic specification layer that this document deliberately excludes.

The model is trained on operator traffic captured under specific deployment conditions. A new operator with different scheduling or different optional procedures will shift the empirical distribution. Recalibration is recommended after a deployment change.

A first-order chain conditions only on the immediately previous message. Attacks that require longer context to recognize, such as sliding security downgrades that span many messages, are not modeled directly. Higher-order extensions are possible but trade off against the data-sparsity issue introduced by larger state pairs.

## 10. Conclusion

The first-order Markov chain layer delivers high-accuracy anomaly detection at a footprint suitable for on-device deployment. Three properties carry the design.

It is small. The trained model occupies under 0.2 MB and answers per-message queries in microseconds, which is compatible with running as a background process on a smartphone.

It is interpretable. Every detection can be explained by pointing to a specific transition probability or a specific field value, which supports both auditing and incremental improvement of the training corpus.

It is unified across networks. A single trained model handles LTE, 5G-SA, and 5G-NSA without separate retraining, because network type is part of the state representation rather than a property of the model.

On a 51-sample evaluation set covering 17,096 messages, the Markov chain layer with a learned threshold of 0.2858 achieves 100% accuracy with no false positives and no false negatives, separating normal traces in $[0.098, 0.247]$ from attack traces in $[0.325, 0.653]$. The deep learning baselines that were tested under the same conditions trail by 8 to 18 percentage points and require two to three orders of magnitude more memory and time per detection.

## 11. Future Work

Three directions are open.

Online adaptation of the transition table would let the model track gradual shifts in operator behavior without a full retraining cycle. The challenge is to update probabilities without allowing a slow attack to be silently absorbed into the normal distribution.

Cross-layer correlation with physical-layer signals such as RSSI and timing advance would extend coverage to attacks that look protocol-valid but are physically inconsistent.

Higher-order Markov extensions over short windows would address attacks that require multi-step context. Keeping the order small, for instance second-order with backoff to first-order under sparsity, is a way to get extra context without breaking the data-efficiency property that motivates the approach in the first place.
